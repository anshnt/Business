;(function ($) {

    "use strict";

    $(document).ready(function () {

        $('.img-hover-scale').each(function () {
            $(this).tilt();
        });
        
    });

})(jQuery);
